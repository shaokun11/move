---
name: ❓ Questions/Help
about: If you have questions, please check Discord
---

## ❓ Questions and Help

### Please note that this issue tracker is not a help form and this issue will be closed.

Please contact the development team on [Discord](https://discord.gg/aptoslabs)
