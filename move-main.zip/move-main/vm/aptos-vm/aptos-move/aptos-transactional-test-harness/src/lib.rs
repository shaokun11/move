// Copyright © Aptos Foundation
// SPDX-License-Identifier: Apache-2.0

mod aptos_test_harness;

pub use aptos_test_harness::run_aptos_test;
