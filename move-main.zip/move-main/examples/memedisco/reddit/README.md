This package was inspired by https://github.com/D3vd/Meme_Api.
